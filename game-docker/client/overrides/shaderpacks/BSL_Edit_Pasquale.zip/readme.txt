﻿===========================================================================
BSL Readme
===========================================================================
THIS SHADER WAS NOT MADE BY ME! The shader was made by Capt Tatsu.
You can contact him through Discord: Capt Tatsu #7124, or Twitter: 
@capttatsu There are a few code changes that I made, so the shader works 
with my maps properly.
===========================================================================
By downloading this shader, you supported his work.
If you want to support it further, you can donate through this link:
https://www.paypal.me/capttatsu
===========================================================================